"use strict";

const prefix = "[Project Astral] ";

exports.info = function(message){
    Log.info(prefix + message);
};

exports.warn = function(message){
    Log.warn(prefix + message);
};

exports.error = function(message){
    Log.err(prefix + message);
};
